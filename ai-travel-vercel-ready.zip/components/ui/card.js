export const Card = ({ children }) => <div className='shadow rounded-xl p-4 border'>{children}</div>;
export const CardContent = ({ children }) => <div>{children}</div>;